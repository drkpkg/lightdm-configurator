#!/bin/bash
DATA="/usr/share/lightdm-configurator"
BIN="/usr/bin/lightdm-configurator"
DESKTOP="/usr/share/applications/lightdm-configurator.desktop"

rm -r $DATA
rm $BIN
rm $DESKTOP

echo "Todo Desinstalado!!"
